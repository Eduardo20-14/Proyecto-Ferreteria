
package ferreteria;

import java.applet.*;
import java.awt.*;

public class Hilo extends Applet implements Runnable 
{
	int PosX=20,PosY=50;  	//Posición de la Hilo
	
	int DirX=PosX % 10 +1;
	int DirY=PosY % 10 +1; 	//Dirección de la Hilo
	int radioPelota=10;	//Radio de la Hilo
	Thread hilo;
	
	public void start()
	{
		if(hilo== null)
		{
			hilo= new Thread(this);
			hilo.start();
		}
	}
	
	public void run() 
	{
	    while(true) 
	    { 
	    mover();
	    repaint(); 

	    try { Thread.sleep(5); 
	    } catch (InterruptedException exc) { } 
	 
	    }
	}


	public void mover()
	{
		PosX+=DirX; 
		PosY+=DirY;
		if ((PosX-radioPelota) <= 0)
		DirX*= -1;
		else if ((PosX+radioPelota) >= getWidth())
	        DirX*= -1;

		if ((PosY-radioPelota) <= 0)
	        DirY*= -1;
	        else if ((PosY+radioPelota) >= getHeight())
	        DirY*= -1;
	}
		
	public void paint(Graphics g)
	{
	g.setColor(Color.RED);
        g.fillOval(PosX-radioPelota, PosY-radioPelota, radioPelota*2, radioPelota*2);
	}
}